# Luke's mutt Readme

mutt is probably best understood by use. If you have a Gmail account, go into the "gmail.conf" file and replace "NAME" with your information to get started. Refer to the config files for the specifics.
