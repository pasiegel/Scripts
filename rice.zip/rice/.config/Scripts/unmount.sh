#!/bin/bash
umount /mnt/* 2> /dev/null
rm -d * 2> /dev/null
