Note: 
- `bin/` contains some bash scripts used by the plugin. Add it to your `PATH`.
- Some code in `ftplugin/tex/live-latex-preview.vim` are commented. That part is not necessary for `pathogen` or `Vundle` users.

- I will update this Repository as soon as I notice a newer version of vim-live-latex-preview. 
- I created a alert and made it a recipe on `ifttt: http://ifttt.com/recipes/2999`.

（for editting latex, I'm using latex-box and the scrip here: http://jlebl.wordpress.com/2011/01/13/vim-evince-and-forward-and-backward-latex-synctex-search/）

Warning:
- This is an unofficial clone of vim-live-latex-preview by Kevin C. Klement <klement@philos.umass.edu>
- For licence info and more details please visit http://aur.archlinux.org/packages.php?ID=42262 (this original link is broken, Oct 13 2015).

